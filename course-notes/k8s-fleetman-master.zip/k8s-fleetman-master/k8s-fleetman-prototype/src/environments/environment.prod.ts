export const environment = {
  production: true,
  gatewayUrl: window.location.hostname + ":" + window.location.port + "/api"
};
