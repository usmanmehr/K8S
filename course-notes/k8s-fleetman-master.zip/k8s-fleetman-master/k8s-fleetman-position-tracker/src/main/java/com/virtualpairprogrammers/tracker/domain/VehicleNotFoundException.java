package com.virtualpairprogrammers.tracker.domain;

@SuppressWarnings("serial")
public class VehicleNotFoundException extends Exception {

}
