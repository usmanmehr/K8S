# K8sFleetmanWebappAngular

This is a project to port the front end to Angular.
